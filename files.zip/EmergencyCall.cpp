#include "EmergencyCall.h"
#include <iostream>
#include <ctime>
#include <iomanip>

EmergencyCall::EmergencyCall(int id, Location loc, int urgency, 
                             const std::string& info)
    : id(id), location(loc), urgencyLevel(urgency), 
      timestamp(time(nullptr)), status(CallStatus::PENDING), 
      patientInfo(info) {
    
    // Validate urgency level
    if (urgencyLevel < 1 || urgencyLevel > 5) {
        std::cerr << "Warning: Urgency level should be between 1 and 5" << std::endl;
        urgencyLevel = std::min(5, std::max(1, urgencyLevel));
    }
}

double EmergencyCall::getAgeInSeconds() const {
    return difftime(time(nullptr), timestamp);
}

double EmergencyCall::getAgeInMinutes() const {
    return getAgeInSeconds() / 60.0;
}

int EmergencyCall::getPriority() const {
    // Priority formula: urgencyLevel * 100 + ageInMinutes
    // This ensures older calls gain priority over time
    return urgencyLevel * 100 + (int)getAgeInMinutes();
}

std::string EmergencyCall::getStatusString() const {
    switch (status) {
        case CallStatus::PENDING:
            return "PENDING";
        case CallStatus::ASSIGNED:
            return "ASSIGNED";
        case CallStatus::EN_ROUTE:
            return "EN_ROUTE";
        case CallStatus::ARRIVED:
            return "ARRIVED";
        case CallStatus::COMPLETED:
            return "COMPLETED";
        case CallStatus::CANCELLED:
            return "CANCELLED";
        default:
            return "UNKNOWN";
    }
}

void EmergencyCall::print() const {
    std::cout << "Emergency Call ID: " << id << std::endl;
    std::cout << "  Location: (" << location.getLatitude() << ", " 
              << location.getLongitude() << ")" << std::endl;
    std::cout << "  Urgency Level: " << urgencyLevel << "/5" << std::endl;
    std::cout << "  Status: " << getStatusString() << std::endl;
    std::cout << "  Age: " << getAgeInMinutes() << " minutes" << std::endl;
    if (!patientInfo.empty()) {
        std::cout << "  Patient Info: " << patientInfo << std::endl;
    }
    std::cout << "  Priority Score: " << getPriority() << std::endl;
}
