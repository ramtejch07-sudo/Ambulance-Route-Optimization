#include "Hospital.h"
#include "Ambulance.h"
#include <iostream>
#include <algorithm>

Hospital::Hospital(double lat, double lon, const std::string& name, int capacity)
    : Location(lat, lon), name(name), totalCapacity(capacity) {
    if (capacity < 1) {
        std::cerr << "Warning: Hospital capacity should be at least 1" << std::endl;
    }
}

int Hospital::getAvailableCapacity() const {
    return totalCapacity - (int)ambulances.size();
}

void Hospital::addAmbulance(Ambulance* ambulance) {
    if (ambulance == nullptr) {
        std::cerr << "Error: Cannot add null ambulance" << std::endl;
        return;
    }
    
    if (getAvailableCapacity() > 0) {
        ambulances.push_back(ambulance);
    } else {
        std::cerr << "Warning: Hospital " << name << " is at full capacity" << std::endl;
    }
}

void Hospital::removeAmbulance(Ambulance* ambulance) {
    if (ambulance == nullptr) {
        std::cerr << "Error: Cannot remove null ambulance" << std::endl;
        return;
    }
    
    auto it = std::find(ambulances.begin(), ambulances.end(), ambulance);
    if (it != ambulances.end()) {
        ambulances.erase(it);
    } else {
        std::cerr << "Warning: Ambulance not found in hospital " << name << std::endl;
    }
}

bool Hospital::isFull() const {
    return ambulances.size() >= (size_t)totalCapacity;
}

bool Hospital::isEmpty() const {
    return ambulances.empty();
}

void Hospital::print() const {
    std::cout << "Hospital: " << name << std::endl;
    std::cout << "  Location: (" << getLatitude() << ", " << getLongitude() << ")" << std::endl;
    std::cout << "  Capacity: " << totalCapacity << std::endl;
    std::cout << "  Current ambulances: " << ambulances.size() << std::endl;
    std::cout << "  Available slots: " << getAvailableCapacity() << std::endl;
}
