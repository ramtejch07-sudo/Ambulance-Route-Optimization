#ifndef EMERGENCYCALL_H
#define EMERGENCYCALL_H

#include "Location.h"
#include <string>
#include <ctime>
#include <iostream>

/**
 * @enum CallStatus
 * @brief Status of an emergency call
 */
enum class CallStatus {
    PENDING,        ///< Waiting for ambulance assignment
    ASSIGNED,       ///< Ambulance has been assigned
    EN_ROUTE,       ///< Ambulance is traveling to location
    ARRIVED,        ///< Ambulance has arrived at scene
    COMPLETED,      ///< Call completed successfully
    CANCELLED       ///< Call was cancelled
};

/**
 * @class EmergencyCall
 * @brief Represents an emergency call with location and urgency
 * 
 * Tracks emergency calls with geographic location, urgency level,
 * and assignment status. Priority is calculated based on urgency
 * and how long the call has been waiting.
 */
class EmergencyCall {
private:
    int id;                         ///< Unique call identifier
    Location location;              ///< Emergency location
    int urgencyLevel;               ///< Urgency: 1 (low) to 5 (critical)
    time_t timestamp;               ///< Time call was received
    CallStatus status;              ///< Current call status
    std::string patientInfo;        ///< Brief patient description

public:
    /**
     * @brief Constructor for EmergencyCall
     * @param id Unique call ID
     * @param loc Emergency location
     * @param urgency Urgency level (1-5)
     * @param info Patient information (optional)
     */
    EmergencyCall(int id, Location loc, int urgency, 
                  const std::string& info = "");
    
    // Getters
    /**
     * @return Call ID
     */
    int getId() const { return id; }
    
    /**
     * @return Emergency location
     */
    Location getLocation() const { return location; }
    
    /**
     * @return Urgency level (1-5)
     */
    int getUrgencyLevel() const { return urgencyLevel; }
    
    /**
     * @return Current call status
     */
    CallStatus getStatus() const { return status; }
    
    /**
     * @return Patient information
     */
    std::string getPatientInfo() const { return patientInfo; }
    
    /**
     * @return Time call was received
     */
    time_t getTimestamp() const { return timestamp; }
    
    // Setters
    /**
     * @brief Update call status
     * @param s New status
     */
    void setStatus(CallStatus s) { status = s; }
    
    /**
     * @brief Set patient information
     * @param info Patient details
     */
    void setPatientInfo(const std::string& info) { patientInfo = info; }
    
    // Methods
    /**
     * @brief Get time elapsed since call was made in seconds
     * @return Age in seconds
     */
    double getAgeInSeconds() const;
    
    /**
     * @brief Get time elapsed in minutes
     * @return Age in minutes
     */
    double getAgeInMinutes() const;
    
    /**
     * @brief Calculate priority score (higher = more urgent)
     * 
     * Priority = urgencyLevel * 100 + ageInMinutes
     * This ensures older calls gain priority over time
     * @return Priority score
     */
    int getPriority() const;
    
    /**
     * @brief Check if call is still pending
     * @return true if status is PENDING
     */
    bool isPending() const { return status == CallStatus::PENDING; }
    
    /**
     * @brief Print call information
     */
    void print() const;
    
    /**
     * @brief Get status as string
     * @return Status string representation
     */
    std::string getStatusString() const;
};

#endif // EMERGENCYCALL_H
