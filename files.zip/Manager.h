#ifndef MANAGER_H
#define MANAGER_H

#include "RouteOptimizer.h"
#include "Ambulance.h"
#include "Hospital.h"
#include "EmergencyCall.h"
#include <vector>
#include <queue>
#include <map>
#include <memory>

/**
 * @class Manager
 * @brief Central manager for the ambulance routing system
 * 
 * Orchestrates all components:
 * - Hospital management
 * - Ambulance fleet management
 * - Emergency call processing
 * - Route assignment and optimization
 * - System monitoring
 */
class Manager {
private:
    std::unique_ptr<RouteOptimizer> optimizer;       ///< Route optimization engine
    std::vector<Hospital> hospitals;                 ///< Network of hospitals
    std::vector<Ambulance> ambulances;               ///< Fleet of ambulances
    std::queue<EmergencyCall> pendingCalls;          ///< Unassigned emergency calls
    std::map<int, Ambulance*> assignedAmbulances;   ///< Call ID -> Ambulance mapping
    
    // Statistics
    int totalCalls = 0;                              ///< Total calls processed
    int successfulAssignments = 0;                   ///< Calls with assigned ambulances
    double totalResponseTime = 0.0;                  ///< Sum of all response times

public:
    /**
     * @brief Constructor
     * @param network Pointer to road network graph
     */
    explicit Manager(Graph* network);
    
    // Destructor
    /**
     * @brief Destructor
     */
    ~Manager();
    
    // Hospital management
    /**
     * @brief Add a hospital to the network
     * @param hospital Hospital object to add
     */
    void addHospital(const Hospital& hospital);
    
    /**
     * @brief Get hospital by index
     * @param index Hospital index
     * @return Reference to hospital
     */
    Hospital& getHospital(int index);
    
    /**
     * @brief Get all hospitals
     * @return Vector of hospitals
     */
    std::vector<Hospital>& getHospitals() { return hospitals; }
    
    /**
     * @return Number of hospitals
     */
    int getHospitalCount() const { return hospitals.size(); }
    
    // Ambulance management
    /**
     * @brief Add an ambulance to the fleet
     * @param ambulance Ambulance object to add
     */
    void addAmbulance(const Ambulance& ambulance);
    
    /**
     * @brief Get ambulance by ID
     * @param id Ambulance ID
     * @return Pointer to ambulance, nullptr if not found
     */
    Ambulance* getAmbulance(int id);
    
    /**
     * @brief Get all ambulances
     * @return Reference to ambulance vector
     */
    std::vector<Ambulance>& getAmbulances() { return ambulances; }
    
    /**
     * @return Total number of ambulances
     */
    int getAmbulanceCount() const { return ambulances.size(); }
    
    /**
     * @return Number of available ambulances
     */
    int getAvailableAmbulanceCount() const;
    
    /**
     * @return Number of busy ambulances
     */
    int getBusyAmbulanceCount() const;
    
    // Call processing
    /**
     * @brief Process an incoming emergency call
     * 
     * Attempts to assign an ambulance. If none available,
     * queues the call for later assignment.
     * 
     * @param call Emergency call to process
     * @return true if ambulance assigned, false if queued
     */
    bool processEmergencyCall(EmergencyCall call);
    
    /**
     * @brief Process multiple emergency calls
     * @param calls Vector of calls to process
     */
    void processEmergencyCalls(std::vector<EmergencyCall>& calls);
    
    /**
     * @brief Get pending (unassigned) calls count
     * @return Number of pending calls
     */
    int getPendingCallsCount() const { return pendingCalls.size(); }
    
    /**
     * @brief Attempt to assign pending calls
     * 
     * Tries to assign any pending calls to newly available ambulances
     */
    void processPendingCalls();
    
    /**
     * @brief Complete an ambulance's current call
     * @param ambulanceId Ambulance ID
     * @param hospitalId Hospital to return to
     */
    void completeCall(int ambulanceId, int hospitalId);
    
    // System monitoring
    /**
     * @brief Update ambulance statuses
     * 
     * Updates all ambulances based on time elapsed and current tasks
     */
    void updateAmbulanceStatuses();
    
    /**
     * @brief Monitor system and reassign if needed
     * 
     * Checks for optimization opportunities and reassigns
     * ambulances if better routes are found
     */
    void monitorAndReassign();
    
    /**
     * @brief Check overall system health
     * 
     * Verifies:
     * - All assignments are valid
     * - No conflicts
     * - All calls being processed
     * 
     * @return true if system is healthy
     */
    bool isSystemHealthy() const;
    
    // Statistics
    /**
     * @brief Get average response time
     * @return Average response time in seconds
     */
    double getAverageResponseTime() const;
    
    /**
     * @brief Get successful assignment rate
     * @return Percentage of calls with assigned ambulances (0-100)
     */
    double getSuccessfulAssignmentRate() const;
    
    /**
     * @return Total calls processed
     */
    int getTotalCallsProcessed() const { return totalCalls; }
    
    /**
     * @return Number of successful assignments
     */
    int getSuccessfulAssignments() const { return successfulAssignments; }
    
    // Reporting
    /**
     * @brief Print system status
     */
    void print() const;
    
    /**
     * @brief Print detailed system report
     */
    void printDetailedReport() const;
    
    /**
     * @brief Print statistics
     */
    void printStatistics() const;
    
    /**
     * @brief Export statistics to file
     * @param filename Output file name
     */
    void exportStatistics(const std::string& filename) const;
};

#endif // MANAGER_H
