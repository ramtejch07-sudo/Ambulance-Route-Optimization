# Ambulance Route Optimization System

**Object-Oriented C++ Project for 12-Week Development**

## 📋 Project Overview

A sophisticated ambulance routing and dispatch system that optimizes emergency response times by automatically assigning ambulances to emergency calls and calculating optimal routes through urban road networks.

### Key Features
- **Location Management**: Geographic coordinate handling with Haversine distance calculations
- **Ambulance Fleet Management**: Track ambulance status, location, and availability
- **Emergency Call Processing**: Priority-based queue system for emergency calls
- **Route Optimization**: Dijkstra's algorithm for shortest path finding
- **Vehicle Routing Problem (VRP)**: Multi-call assignment optimization
- **Hospital Network**: Capacity management across hospital facilities

## 🏗️ System Architecture

### Class Hierarchy
```
Location (Base class)
  ├── Hospital (extends Location)
  └── Used by: Ambulance, Route, EmergencyCall

Ambulance (Base entity)
  └── Used by: Manager, RouteOptimizer

EmergencyCall (Base entity)
  └── Used by: Manager, RouteOptimizer

Route (Path representation)
  └── Used by: RouteOptimizer, Manager

Graph (Road network)
  └── Used by: RouteOptimizer

RouteOptimizer (Algorithm engine)
  └── Used by: Manager

Manager (System orchestrator)
  └── Main coordinator
```

## 🚀 Getting Started

### Prerequisites
- C++ 17 or later
- CMake 3.10+
- GCC/Clang compiler
- Linux/MacOS/Windows

### Setup Instructions

#### 1. Clone the Repository
```bash
git clone https://github.com/ramtejch07-sudo/Ambulance-Route-Optimization.git
cd Ambulance-Route-Optimization
```

#### 2. Create Build Directory
```bash
mkdir build
cd build
```

#### 3. Generate Build Files
```bash
cmake ..
```

#### 4. Compile
```bash
make
```

Or with verbose output:
```bash
make VERBOSE=1
```

#### 5. Run the Application
```bash
./ambulance_route_optimization
```

### Windows (PowerShell) Setup
```powershell
# Create build directory
mkdir build
cd build

# Generate Visual Studio project files
cmake .. -G "Visual Studio 16 2019"

# Build
cmake --build . --config Release

# Run
.\Release\ambulance_route_optimization.exe
```

## 📁 Project Structure

```
Ambulance-Route-Optimization/
├── include/              # Header files
│   ├── Location.h
│   ├── Hospital.h
│   ├── Ambulance.h
│   ├── EmergencyCall.h
│   ├── Route.h
│   ├── Graph.h
│   ├── RouteOptimizer.h
│   └── Manager.h
├── src/                  # Implementation files
│   ├── main.cpp
│   ├── Location.cpp
│   ├── Hospital.cpp
│   ├── Ambulance.cpp
│   ├── EmergencyCall.cpp
│   ├── Route.cpp
│   ├── Graph.cpp
│   ├── RouteOptimizer.cpp
│   └── Manager.cpp
├── tests/                # Test files (future)
│   └── test.cpp
├── data/                 # Sample data files
│   └── maps/
│       └── sample_map.csv
├── docs/                 # Documentation
├── CMakeLists.txt        # Build configuration
├── README.md             # This file
└── .gitignore
```

## 💻 Usage Examples

### Basic Example
```cpp
#include "Manager.h"

int main() {
    // Create road network
    Graph roadNetwork(10);
    roadNetwork.addEdge(0, 1, 1000);  // 1km road
    
    // Create system manager
    Manager manager(&roadNetwork);
    
    // Add hospitals
    Hospital hospital(40.7128, -74.0060, "General Hospital", 5);
    manager.addHospital(hospital);
    
    // Add ambulances
    Location baseLocation(40.7128, -74.0060);
    for (int i = 1; i <= 3; i++) {
        Ambulance amb(i, baseLocation, 2);
        manager.addAmbulance(amb);
    }
    
    // Process emergency call
    Location emergencyLoc(40.7150, -74.0070);
    EmergencyCall call(1, emergencyLoc, 4, "Chest pain");
    manager.processEmergencyCall(call);
    
    // Print status
    manager.print();
    
    return 0;
}
```

### Advanced Example: Multiple Calls
```cpp
// Create multiple emergency calls
std::vector<EmergencyCall> calls;
calls.push_back(EmergencyCall(1, loc1, 5, "Critical"));
calls.push_back(EmergencyCall(2, loc2, 3, "Moderate"));
calls.push_back(EmergencyCall(3, loc3, 2, "Minor"));

// Process all calls
manager.processEmergencyCalls(calls);

// Get statistics
std::cout << "Success rate: " << manager.getSuccessfulAssignmentRate() << "%" << std::endl;
std::cout << "Average response time: " << manager.getAverageResponseTime() << " seconds" << std::endl;
```

## 📊 Data Format

### Map File Format (CSV)
```
NODES: count
ID,Latitude,Longitude,Type,Name
0,40.7128,-74.0060,HOSPITAL,General Hospital
1,40.7150,-74.0070,INTERSECTION,Main St
2,40.7180,-74.0080,INTERSECTION,5th Ave

EDGES: count
FromID,ToID,Distance,Time
0,1,500,120
1,2,800,200
```

## 🔑 Key Classes

### Location
Represents a geographic point using latitude/longitude coordinates.
- `getDistance(Location)`: Calculates distance using Haversine formula
- `operator==`: Compares locations

### Ambulance
Manages ambulance state, position, and status.
- `isAvailable()`: Checks if ambulance can be dispatched
- `getDistance(Location)`: Distance to target location
- Status: AVAILABLE, EN_ROUTE, AT_HOSPITAL, BUSY

### EmergencyCall
Represents an emergency call with priority.
- `getPriority()`: Dynamic priority based on urgency and wait time
- Status: PENDING, ASSIGNED, EN_ROUTE, ARRIVED, COMPLETED

### Graph
Road network representation using adjacency list.
- `dijkstra(start, end)`: Find shortest path
- `addEdge(from, to, weight)`: Add road

### RouteOptimizer
Core optimization engine.
- `assignOptimalAmbulance()`: Assign nearest ambulance
- `optimizeMultipleCalls()`: Solve VRP

### Manager
System orchestrator coordinating all components.
- `processEmergencyCall()`: Handle incoming call
- `processPendingCalls()`: Assign queued calls
- `printStatistics()`: System performance metrics

## 📈 Development Roadmap

### Phase 1: Foundation (Weeks 1-2) ✅
- [x] Project structure
- [x] Core classes
- [x] Basic implementation

### Phase 2: Core Algorithms (Weeks 3-4)
- [ ] Location/Hospital/Ambulance enhancements
- [ ] Data validation
- [ ] Sample data generation

### Phase 3: Optimization (Weeks 5-6)
- [ ] Graph implementation
- [ ] Dijkstra's algorithm
- [ ] A* pathfinding

### Phase 4: Assignment (Weeks 7-8)
- [ ] Ambulance assignment algorithm
- [ ] VRP solver
- [ ] Multi-call optimization

### Phase 5: Advanced (Weeks 9-10)
- [ ] Traffic modeling
- [ ] Simulation framework
- [ ] Performance optimization

### Phase 6: Finalization (Weeks 11-12)
- [ ] Comprehensive testing
- [ ] Documentation
- [ ] Performance profiling

## 🧪 Testing

### Run Tests (Future)
```bash
cd build
ctest --output-on-failure
```

### Manual Testing
```bash
./ambulance_route_optimization
```

### Expected Output
```
╔══════════════════════════════════════════════════════════╗
║   Ambulance Route Optimization System - Week 1-2         ║
║   OOP C++ Project                                        ║
╚══════════════════════════════════════════════════════════╝

=== Testing Location Class ===
...
```

## 📊 Performance Metrics

### Target Performance (Week 12)
- **Response Time**: < 100ms for graph size 1000 nodes
- **Path Calculation**: Dijkstra O(V log V) complexity
- **VRP Assignment**: < 50ms for 20 calls
- **Code Coverage**: 85%+
- **Test Suite**: 75+ test cases

## 🐛 Troubleshooting

### Build Errors

**"cmake: command not found"**
```bash
sudo apt-get install cmake
# or
brew install cmake  # macOS
```

**"g++: command not found"**
```bash
sudo apt-get install build-essential
# or
brew install gcc  # macOS
```

**CMake configuration fails**
```bash
rm -rf build
mkdir build
cd build
cmake .. -DCMAKE_CXX_COMPILER=g++
make
```

### Runtime Issues

**"No ambulances available"**
- Normal behavior - calls are queued
- System will assign when ambulances become available

**Incorrect distance calculations**
- Verify GPS coordinates are in valid ranges
- Latitude: -90 to 90
- Longitude: -180 to 180

## 📝 Code Quality Standards

- **Style**: Google C++ Style Guide
- **Comments**: Doxygen format
- **Naming**: camelCase for variables, PascalCase for classes
- **Error Handling**: Try-catch for exceptions
- **Memory**: Smart pointers (unique_ptr, shared_ptr)

## 📚 Documentation

- `PROGRESS.md`: Weekly progress tracker
- `12-week-plan.md`: Detailed roadmap
- `API_DOCS.md`: Generated Doxygen documentation

## 🤝 Contributing

### Weekly Workflow
1. Create feature branch: `git checkout -b week-X-feature`
2. Implement changes
3. Test thoroughly
4. Commit with meaningful message
5. Create Pull Request
6. Merge to main after review

### Commit Message Format
```
Week X: [Title]

- Implementation detail 1
- Implementation detail 2
- Tests added: N/M passing

Performance improvement: X%
```

## 📄 License

This project is part of an academic OOP course. Refer to course guidelines for usage rights.

## 👥 Authors

- Primary Developer: Thomas (homashashank)
- Course: Object-Oriented Programming with C++
- Institution: [University/College Name]

## 📞 Support

For issues or questions:
1. Check this README
2. Review the 12-week plan document
3. Check GitHub Issues
4. Contact course instructor

## 🎯 Success Criteria (Week 12 Completion)

- [x] Compiles with 0 errors, 0 warnings
- [ ] 5000+ lines of OOP C++ code
- [ ] 8+ well-designed classes
- [ ] 75+ test cases with 85% coverage
- [ ] Complete documentation
- [ ] Performance profiling done
- [ ] GitHub repository with weekly commits
- [ ] v1.0 release tagged

---

**Status**: Week 1-2 ✅ In Progress

**Last Updated**: 2026-09-03

**Next Milestone**: Week 3 - Core Class Implementation

