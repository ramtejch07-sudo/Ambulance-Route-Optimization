#include "Graph.h"
#include <iostream>
#include <algorithm>
#include <iomanip>

Graph::Graph(int nodes) : numNodes(nodes) {}

void Graph::addNode(int nodeId, const std::string& label) {
    if (adjacencyList.find(nodeId) == adjacencyList.end()) {
        adjacencyList[nodeId] = std::vector<std::pair<int, double>>();
        nodeLabels[nodeId] = label.empty() ? "Node" + std::to_string(nodeId) : label;
    }
}

void Graph::addEdge(int from, int to, double weight, bool bidirectional) {
    addNode(from);
    addNode(to);
    
    // Add forward edge
    adjacencyList[from].push_back({to, weight});
    
    // Add reverse edge if bidirectional
    if (bidirectional) {
        adjacencyList[to].push_back({from, weight});
    }
}

void Graph::removeEdge(int from, int to) {
    if (adjacencyList.find(from) != adjacencyList.end()) {
        auto& neighbors = adjacencyList[from];
        neighbors.erase(
            std::remove_if(neighbors.begin(), neighbors.end(),
                          [to](const std::pair<int, double>& p) { return p.first == to; }),
            neighbors.end()
        );
    }
}

std::vector<std::pair<int, double>> Graph::getNeighbors(int nodeId) const {
    if (adjacencyList.find(nodeId) != adjacencyList.end()) {
        return adjacencyList.at(nodeId);
    }
    return std::vector<std::pair<int, double>>();
}

double Graph::getEdgeWeight(int from, int to) const {
    auto neighbors = getNeighbors(from);
    for (const auto& neighbor : neighbors) {
        if (neighbor.first == to) {
            return neighbor.second;
        }
    }
    return -1.0; // Edge not found
}

std::string Graph::getNodeLabel(int nodeId) const {
    if (nodeLabels.find(nodeId) != nodeLabels.end()) {
        return nodeLabels.at(nodeId);
    }
    return "Unknown";
}

bool Graph::isConnected(int from, int to) const {
    return getEdgeWeight(from, to) >= 0.0;
}

bool Graph::nodeExists(int nodeId) const {
    return adjacencyList.find(nodeId) != adjacencyList.end();
}

std::vector<int> Graph::getReachableNodes(int source) const {
    std::vector<bool> visited(numNodes, false);
    std::vector<int> reachable;
    
    std::queue<int> q;
    q.push(source);
    visited[source] = true;
    
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        reachable.push_back(node);
        
        auto neighbors = getNeighbors(node);
        for (const auto& neighbor : neighbors) {
            if (!visited[neighbor.first]) {
                visited[neighbor.first] = true;
                q.push(neighbor.first);
            }
        }
    }
    
    return reachable;
}

std::vector<int> Graph::dijkstra(int start, int end) {
    std::vector<double> distances(numNodes, std::numeric_limits<double>::max());
    std::vector<int> predecessors(numNodes, -1);
    std::priority_queue<std::pair<double, int>,
                       std::vector<std::pair<double, int>>,
                       std::greater<std::pair<double, int>>> pq;
    
    distances[start] = 0.0;
    pq.push({0.0, start});
    
    while (!pq.empty()) {
        auto [currentDist, current] = pq.top();
        pq.pop();
        
        if (currentDist > distances[current]) {
            continue;
        }
        
        auto neighbors = getNeighbors(current);
        for (const auto& [neighbor, weight] : neighbors) {
            double newDist = distances[current] + weight;
            if (newDist < distances[neighbor]) {
                distances[neighbor] = newDist;
                predecessors[neighbor] = current;
                pq.push({newDist, neighbor});
            }
        }
    }
    
    // Reconstruct path
    std::vector<int> path;
    if (distances[end] == std::numeric_limits<double>::max()) {
        return path; // No path found
    }
    
    int current = end;
    while (current != -1) {
        path.insert(path.begin(), current);
        current = predecessors[current];
    }
    
    return path;
}

std::map<int, int> Graph::dijkstraDistances(int start, 
                                            std::vector<double>& distances) {
    distances.assign(numNodes, std::numeric_limits<double>::max());
    std::map<int, int> predecessors;
    std::priority_queue<std::pair<double, int>,
                       std::vector<std::pair<double, int>>,
                       std::greater<std::pair<double, int>>> pq;
    
    distances[start] = 0.0;
    pq.push({0.0, start});
    
    while (!pq.empty()) {
        auto [currentDist, current] = pq.top();
        pq.pop();
        
        if (currentDist > distances[current]) {
            continue;
        }
        
        auto neighbors = getNeighbors(current);
        for (const auto& [neighbor, weight] : neighbors) {
            double newDist = distances[current] + weight;
            if (newDist < distances[neighbor]) {
                distances[neighbor] = newDist;
                predecessors[neighbor] = current;
                pq.push({newDist, neighbor});
            }
        }
    }
    
    return predecessors;
}

void Graph::dfs(int node, std::vector<bool>& visited) const {
    visited[node] = true;
    auto neighbors = getNeighbors(node);
    for (const auto& neighbor : neighbors) {
        if (!visited[neighbor.first]) {
            dfs(neighbor.first, visited);
        }
    }
}

bool Graph::isConnected() const {
    if (adjacencyList.empty()) {
        return true;
    }
    
    std::vector<bool> visited(numNodes, false);
    dfs(adjacencyList.begin()->first, visited);
    
    for (size_t i = 0; i < visited.size(); i++) {
        if (nodeExists(i) && !visited[i]) {
            return false;
        }
    }
    
    return true;
}

void Graph::clear() {
    adjacencyList.clear();
    nodeLabels.clear();
}

int Graph::getEdgeCount() const {
    int count = 0;
    for (const auto& [node, neighbors] : adjacencyList) {
        count += neighbors.size();
    }
    return count / 2; // Divide by 2 for bidirectional edges
}

void Graph::print() const {
    std::cout << "=== Graph Information ===" << std::endl;
    std::cout << "Nodes: " << adjacencyList.size() << std::endl;
    std::cout << "Edges: " << getEdgeCount() << std::endl;
    std::cout << std::endl;
    
    for (const auto& [node, neighbors] : adjacencyList) {
        std::cout << "Node " << node << " (" << getNodeLabel(node) << ") -> ";
        for (const auto& [neighbor, weight] : neighbors) {
            std::cout << neighbor << "(" << std::fixed << std::setprecision(2) 
                     << weight << ") ";
        }
        std::cout << std::endl;
    }
}

void Graph::printAdjacencyList() const {
    std::cout << "=== Adjacency List ===" << std::endl;
    for (const auto& [node, neighbors] : adjacencyList) {
        std::cout << node << ": ";
        for (const auto& [neighbor, weight] : neighbors) {
            std::cout << neighbor << " ";
        }
        std::cout << std::endl;
    }
}

void Graph::printStatistics() const {
    std::cout << "=== Graph Statistics ===" << std::endl;
    std::cout << "Number of nodes: " << adjacencyList.size() << std::endl;
    std::cout << "Number of edges: " << getEdgeCount() << std::endl;
    std::cout << "Connected: " << (isConnected() ? "Yes" : "No") << std::endl;
}
