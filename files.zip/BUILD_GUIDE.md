# Build Guide - Ambulance Route Optimization

Complete step-by-step guide for compiling and running the project on Windows, Linux, and macOS.

---

## 🖥️ Windows (PowerShell) - Recommended

### Prerequisites
- Visual Studio 2019+ or MinGW
- CMake 3.10+
- Git

### Step-by-Step

#### 1. Navigate to Project Directory
```powershell
cd C:\Users\thomas\OneDrive\Tai lièu\btech\Ambulance-Route-Optimization
```

#### 2. Create Build Directory
```powershell
if (!(Test-Path build)) { 
    mkdir build 
}
cd build
```

#### 3. Generate Build Files
**Option A: Visual Studio (Recommended)**
```powershell
cmake .. -G "Visual Studio 16 2019"
```

**Option B: MinGW**
```powershell
cmake .. -G "MinGW Makefiles"
```

**Option C: NMake**
```powershell
cmake .. -G "NMake Makefiles"
```

#### 4. Build the Project
**Using Visual Studio:**
```powershell
cmake --build . --config Release
```

**Using MinGW/NMake:**
```powershell
make
```

#### 5. Run the Application
**With Visual Studio:**
```powershell
.\Release\ambulance_route_optimization.exe
```

**With MinGW:**
```powershell
.\ambulance_route_optimization.exe
```

### Troubleshooting Windows

**Error: cmake: command not found**
```powershell
# Install CMake via Chocolatey
choco install cmake

# Or download from https://cmake.org/download/
```

**Error: cl.exe not found**
```powershell
# Add Visual Studio tools to PATH
$env:PATH += "C:\Program Files\Microsoft Visual Studio\2019\Community\VC\Tools\MSVC\14.XX\bin\Hostx64\x64"
```

**Building with specific compiler:**
```powershell
cmake .. -G "Visual Studio 16 2019" -A x64
cmake --build . --config Release -- /m:4
```

### Windows-Specific Tips
- Use PowerShell instead of CMD for better compatibility
- Paths with spaces should work correctly with quotes
- Build cache: Delete `build` folder to clean build

---

## 🐧 Linux / Ubuntu

### Prerequisites
```bash
sudo apt-get update
sudo apt-get install -y build-essential cmake git
```

### Step-by-Step

#### 1. Navigate to Project
```bash
cd ~/projects/Ambulance-Route-Optimization
# or wherever you cloned it
```

#### 2. Create and Enter Build Directory
```bash
mkdir -p build
cd build
```

#### 3. Generate Build Files
```bash
cmake ..
```

#### 4. Compile the Project
```bash
# Using all available cores
make -j$(nproc)

# Or with verbose output
make VERBOSE=1

# Or using CMake directly
cmake --build . --config Release -j4
```

#### 5. Run the Application
```bash
./ambulance_route_optimization
```

### Linux Troubleshooting

**Error: CMake version too old**
```bash
# Install newer CMake
sudo apt-get remove cmake
sudo snap install cmake --classic
```

**Error: C++ compiler not found**
```bash
sudo apt-get install -y g++ gcc
```

**Build fails with "permission denied"**
```bash
sudo chmod +x build/ambulance_route_optimization
./build/ambulance_route_optimization
```

### Linux-Specific Tips
- Use `make -j$(nproc)` for parallel builds (faster)
- Clean build: `rm -rf build && mkdir build`
- Use `ccache` for faster rebuilds: `sudo apt-get install ccache`

---

## 🍎 macOS

### Prerequisites
```bash
# Install Xcode Command Line Tools
xcode-select --install

# Install CMake via Homebrew
brew install cmake
```

### Step-by-Step

#### 1. Navigate to Project
```bash
cd ~/Ambulance-Route-Optimization
```

#### 2. Create Build Directory
```bash
mkdir build
cd build
```

#### 3. Generate Build Files
```bash
cmake ..
```

#### 4. Build
```bash
make -j$(sysctl -n hw.ncpu)
```

#### 5. Run
```bash
./ambulance_route_optimization
```

### macOS Troubleshooting

**Error: command not found: cmake**
```bash
brew install cmake
# Or add to PATH
export PATH="/usr/local/bin:$PATH"
```

**M1/M2 Mac issues**
```bash
# Use native architecture
cmake .. -DCMAKE_OSX_ARCHITECTURES=arm64
```

**Clang compiler errors**
```bash
# Ensure Xcode is up to date
sudo xcode-select --reset
xcode-select --install
```

---

## 📋 Common CMake Options

### Build with Optimizations
```bash
cmake .. -DCMAKE_BUILD_TYPE=Release
make
```

### Debug Build
```bash
cmake .. -DCMAKE_BUILD_TYPE=Debug
make
```

### Enable All Warnings
```bash
cmake .. -DCMAKE_CXX_FLAGS="-Wall -Wextra -pedantic"
make
```

### Static Linking
```bash
cmake .. -DBUILD_SHARED_LIBS=OFF
make
```

### Verbose Output
```bash
make VERBOSE=1
# or
cmake --build . --verbose
```

### Install After Build
```bash
cmake --install . --prefix $HOME/ambulance-app
```

---

## 🔍 Verification Checklist

After building, verify:

```bash
# 1. Executable exists
ls -la ambulance_route_optimization  # Linux/macOS
dir ambulance_route_optimization.exe  # Windows

# 2. Run the program
./ambulance_route_optimization

# 3. Check output (should show tests)
# Look for "All Tests Completed!"

# 4. Verify no errors
echo $?  # Should return 0 on Linux/macOS
```

---

## 🚀 Quick Build Scripts

### Linux/macOS One-Liner
```bash
cd ~/Ambulance-Route-Optimization && rm -rf build && mkdir build && cd build && cmake .. && make -j$(nproc) && ./ambulance_route_optimization
```

### Windows PowerShell One-Liner
```powershell
cd "C:\Users\thomas\OneDrive\Tai lièu\btech\Ambulance-Route-Optimization"; Remove-Item -Recurse -Force build -ErrorAction SilentlyContinue; mkdir build | out-null; cd build; cmake .. -G "Visual Studio 16 2019"; cmake --build . --config Release; .\Release\ambulance_route_optimization.exe
```

### Auto-Build Shell Script (Linux/macOS)

Create `build.sh`:
```bash
#!/bin/bash

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="$PROJECT_DIR/build"

echo "Building Ambulance Route Optimization..."

# Clean previous build
rm -rf "$BUILD_DIR"

# Create build directory
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

# Generate build files
echo "Generating build files..."
cmake ..

# Build project
echo "Compiling..."
make -j$(nproc)

# Check if successful
if [ -f "./ambulance_route_optimization" ]; then
    echo "✅ Build successful!"
    echo "Running application..."
    ./ambulance_route_optimization
else
    echo "❌ Build failed!"
    exit 1
fi
```

Run it:
```bash
chmod +x build.sh
./build.sh
```

---

## 📊 Expected Output

After successful compilation and run:

```
╔══════════════════════════════════════════════════════════╗
║   Ambulance Route Optimization System - Week 1-2         ║
║   OOP C++ Project                                        ║
╚══════════════════════════════════════════════════════════╝

Running Week 1-2 Basic Tests...
================================
=== Testing Location Class ===
Location (40.712800, -74.006000)
Location (40.715000, -74.007000)
Distance between locations: 2589.45 meters
Are they equal? No

=== Testing Ambulance Class ===
[... more test output ...]

╔══════════════════════════════════════════════════════════╗
║                  All Tests Completed!                    ║
║                                                          ║
║  Next Steps:                                             ║
║  - Week 3: Implement core algorithms                    ║
║  - Week 4: Add data validation                          ║
║  - Week 5-6: Implement pathfinding                      ║
╚══════════════════════════════════════════════════════════╝
```

---

## 🧹 Cleaning

### Clean Build Artifacts (Keep Source)
```bash
cd build
make clean
# or
cmake --build . --target clean
```

### Full Clean (Delete Everything Built)
```bash
rm -rf build/
```

### Clean Intermediate Files Only
```bash
cd build
find . -name "CMakeFiles" -type d -exec rm -rf {} +
```

---

## 🔧 Troubleshooting Checklist

| Issue | Solution |
|-------|----------|
| "cmake not found" | Install CMake |
| "C++ compiler not found" | Install GCC/Clang/MSVC |
| "Permission denied" | Use `chmod +x` on executable |
| "Undefined reference to..." | Check all source files included |
| "Cannot find Location.h" | Verify include_directories in CMakeLists.txt |
| "Build takes forever" | Use `-j` flag: `make -j4` |
| "Out of memory" | Reduce parallel builds: `make -j1` |
| "Path too long (Windows)" | Use shorter path or enable long paths |

---

## 📈 Performance Tips

### Faster Builds
```bash
# Use ccache (Linux/macOS)
cmake .. -DCMAKE_CXX_COMPILER_LAUNCHER=ccache

# Parallel build with 4 cores
make -j4

# Incremental build
make -j$(nproc)
```

### Memory Usage
```bash
# Single-threaded build (low memory)
make -j1

# Distributed build with distcc
cmake .. -DCMAKE_CXX_COMPILER_LAUNCHER=distcc
```

### Profiling Builds
```bash
# Time the build
time make

# See which files take longest
make -d | grep "^  "
```

---

## 🔗 Project Structure After Build

```
Ambulance-Route-Optimization/
├── build/                          # BUILD DIRECTORY
│   ├── CMakeCache.txt
│   ├── CMakeFiles/
│   ├── Makefile (Linux/macOS)
│   ├── ambulance_route_optimization (executable)
│   ├── cmake_install.cmake
│   └── *.sln, *.vcxproj (Windows)
├── include/
│   └── [header files]
├── src/
│   └── [source files]
└── ...
```

---

## 📞 Build Support

If build fails:

1. **Check prerequisites installed**
   ```bash
   cmake --version
   g++ --version  # or clang++ --version
   ```

2. **Check CMakeLists.txt is valid**
   ```bash
   cmake .. --debug-output
   ```

3. **Try clean build**
   ```bash
   rm -rf build
   mkdir build
   cd build
   cmake ..
   make VERBOSE=1
   ```

4. **Check compilation flags**
   ```bash
   cmake -LH ..
   ```

---

## ✅ Success Criteria

Build is successful when:

- [x] CMake generates without errors
- [x] Make/compilation completes without errors
- [x] Executable is created
- [x] Program runs and shows tests
- [x] Output shows "All Tests Completed!"
- [x] Return code is 0

---

**Last Updated**: 2026-09-03  
**CMake Version**: 3.10+  
**C++ Standard**: C++17

Good luck building! 🚀

