#include "Route.h"
#include <iostream>
#include <iomanip>

Route::Route() : totalDistance(0.0), estimatedTime(0.0) {}

Route::Route(Location start) : totalDistance(0.0), estimatedTime(0.0) {
    waypoints.push_back(start);
}

void Route::addWaypoint(Location loc) {
    waypoints.push_back(loc);
    calculateDistance();
    calculateTime();
}

void Route::addWaypoints(const std::vector<Location>& locations) {
    for (const auto& loc : locations) {
        waypoints.push_back(loc);
    }
    calculateDistance();
    calculateTime();
}

void Route::clearWaypoints() {
    waypoints.clear();
    totalDistance = 0.0;
    estimatedTime = 0.0;
}

void Route::calculateDistance() {
    totalDistance = 0.0;
    if (waypoints.size() < 2) {
        return;
    }
    
    for (size_t i = 0; i < waypoints.size() - 1; i++) {
        totalDistance += waypoints[i].getDistance(waypoints[i + 1]);
    }
}

void Route::calculateTime() {
    // Assuming average speed of 40 km/h = 11.11 m/s
    // time = distance / speed
    const double AVERAGE_SPEED_MPS = 11.11;
    
    if (totalDistance > 0) {
        estimatedTime = totalDistance / AVERAGE_SPEED_MPS;
    } else {
        estimatedTime = 0.0;
    }
}

bool Route::operator==(const Route& other) const {
    if (waypoints.size() != other.waypoints.size()) {
        return false;
    }
    
    for (size_t i = 0; i < waypoints.size(); i++) {
        if (!(waypoints[i] == other.waypoints[i])) {
            return false;
        }
    }
    
    return true;
}

Location Route::getStart() const {
    if (waypoints.empty()) {
        return Location();
    }
    return waypoints.front();
}

Location Route::getEnd() const {
    if (waypoints.empty()) {
        return Location();
    }
    return waypoints.back();
}

void Route::print() const {
    std::cout << "Route with " << waypoints.size() << " waypoints" << std::endl;
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "  Distance: " << totalDistance << " m (" 
              << (totalDistance / 1000.0) << " km)" << std::endl;
    std::cout << "  Estimated Time: " << estimatedTime << " s (" 
              << getEstimatedTimeMinutes() << " minutes)" << std::endl;
}

void Route::printDetailed() const {
    std::cout << "=== Route Details ===" << std::endl;
    std::cout << "Total waypoints: " << waypoints.size() << std::endl;
    std::cout << std::fixed << std::setprecision(6);
    
    for (size_t i = 0; i < waypoints.size(); i++) {
        std::cout << "  Stop " << (i + 1) << ": (" 
                  << waypoints[i].getLatitude() << ", "
                  << waypoints[i].getLongitude() << ")" << std::endl;
    }
    
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "Total Distance: " << totalDistance << " m" << std::endl;
    std::cout << "Estimated Time: " << estimatedTime << " s" << std::endl;
}
