#ifndef AMBULANCE_H
#define AMBULANCE_H

#include "Location.h"
#include <string>
#include <iostream>

/**
 * @enum AmbulanceStatus
 * @brief Possible states of an ambulance
 */
enum class AmbulanceStatus {
    AVAILABLE,      ///< Ready to respond to calls
    EN_ROUTE,       ///< Currently traveling to emergency
    AT_HOSPITAL,    ///< At hospital for patient drop-off
    BUSY,           ///< Under service, not available
    MAINTENANCE     ///< Under maintenance
};

/**
 * @class Ambulance
 * @brief Represents an ambulance with location and status tracking
 * 
 * Manages ambulance state, position, and availability for emergency calls.
 */
class Ambulance {
private:
    int id;                         ///< Unique ambulance identifier
    AmbulanceStatus status;         ///< Current status
    Location currentLocation;       ///< Current GPS location
    int capacity;                   ///< Patient capacity (usually 2-3)

public:
    /**
     * @brief Constructor for Ambulance
     * @param id Unique ambulance ID
     * @param loc Initial location
     * @param cap Patient capacity (default: 2)
     */
    Ambulance(int id, Location loc, int cap = 2);
    
    // Getters
    /**
     * @return Ambulance ID
     */
    int getId() const { return id; }
    
    /**
     * @return Current status
     */
    AmbulanceStatus getStatus() const { return status; }
    
    /**
     * @return Current location reference
     */
    Location& getCurrentLocation() { return currentLocation; }
    
    /**
     * @return Const reference to current location
     */
    const Location& getCurrentLocation() const { return currentLocation; }
    
    /**
     * @return Patient capacity
     */
    int getCapacity() const { return capacity; }
    
    // Setters
    /**
     * @brief Update ambulance status
     * @param s New status
     */
    void setStatus(AmbulanceStatus s) { status = s; }
    
    /**
     * @brief Update ambulance location
     * @param loc New location
     */
    void updateLocation(Location loc) { currentLocation = loc; }
    
    // Methods
    /**
     * @brief Check if ambulance is available
     * @return true if status is AVAILABLE
     */
    bool isAvailable() const { return status == AmbulanceStatus::AVAILABLE; }
    
    /**
     * @brief Check if ambulance is busy
     * @return true if status is not AVAILABLE
     */
    bool isBusy() const { return status != AmbulanceStatus::AVAILABLE; }
    
    /**
     * @brief Calculate distance to a location
     * @param loc Target location
     * @return Distance in meters
     */
    double getDistance(const Location& loc) const;
    
    /**
     * @brief Print ambulance information
     */
    void print() const;
    
    /**
     * @brief Get status as string
     * @return Status string representation
     */
    std::string getStatusString() const;
};

#endif // AMBULANCE_H
