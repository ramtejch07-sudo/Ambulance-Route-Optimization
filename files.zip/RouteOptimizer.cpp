#include "RouteOptimizer.h"
#include <iostream>
#include <algorithm>
#include <cmath>
#include <limits>

RouteOptimizer::RouteOptimizer(Graph* network) : roadNetwork(network) {}

RouteOptimizer::~RouteOptimizer() {
    // Don't delete roadNetwork as we don't own it
}

Route RouteOptimizer::findShortestPath(Location start, Location end) {
    Route route;
    route.addWaypoint(start);
    route.addWaypoint(end);
    
    // TODO: Implement actual pathfinding using graph
    // For now, return direct route
    route.calculateDistance();
    route.calculateTime();
    
    return route;
}

Route RouteOptimizer::findFastestRoute(Location start, Location end) {
    // For now, same as shortest path
    // In real implementation, would consider speed limits
    return findShortestPath(start, end);
}

std::vector<Route> RouteOptimizer::getAllAlternativeRoutes(Location start, 
                                                           Location end, 
                                                           int maxRoutes) {
    std::vector<Route> routes;
    // TODO: Implement multiple route generation
    routes.push_back(findShortestPath(start, end));
    return routes;
}

Ambulance* RouteOptimizer::assignOptimalAmbulance(EmergencyCall& call, 
                                                  std::vector<Ambulance>& ambulances) {
    Ambulance* nearest = nullptr;
    double minDistance = std::numeric_limits<double>::max();
    
    for (auto& amb : ambulances) {
        if (amb.isAvailable()) {
            double dist = amb.getDistance(call.getLocation());
            if (dist < minDistance) {
                minDistance = dist;
                nearest = &amb;
            }
        }
    }
    
    return nearest;
}

std::vector<Ambulance*> RouteOptimizer::getNearestAmbulances(EmergencyCall& call,
                                                              std::vector<Ambulance>& ambulances,
                                                              int count) {
    std::vector<std::pair<double, Ambulance*>> distances;
    
    for (auto& amb : ambulances) {
        if (amb.isAvailable()) {
            double dist = amb.getDistance(call.getLocation());
            distances.push_back({dist, &amb});
        }
    }
    
    // Sort by distance
    std::sort(distances.begin(), distances.end());
    
    std::vector<Ambulance*> result;
    for (int i = 0; i < std::min((int)distances.size(), count); i++) {
        result.push_back(distances[i].second);
    }
    
    return result;
}

std::vector<Ambulance*> RouteOptimizer::getAmbulancesByETA(EmergencyCall& call,
                                                           std::vector<Ambulance>& ambulances,
                                                           int count) {
    // ETA = distance / speed (40 km/h = 11.11 m/s)
    std::vector<std::pair<double, Ambulance*>> etas;
    
    for (auto& amb : ambulances) {
        if (amb.isAvailable()) {
            double dist = amb.getDistance(call.getLocation());
            double eta = dist / 11.11; // seconds
            etas.push_back({eta, &amb});
        }
    }
    
    // Sort by ETA
    std::sort(etas.begin(), etas.end());
    
    std::vector<Ambulance*> result;
    for (int i = 0; i < std::min((int)etas.size(), count); i++) {
        result.push_back(etas[i].second);
    }
    
    return result;
}

std::vector<Route> RouteOptimizer::optimizeMultipleCalls(std::vector<EmergencyCall>& calls,
                                                         std::vector<Ambulance>& ambulances) {
    // Use Nearest Neighbor for now
    return solveVRPNearestNeighbor(calls, ambulances);
}

std::vector<Route> RouteOptimizer::solveVRPNearestNeighbor(std::vector<EmergencyCall>& calls,
                                                           std::vector<Ambulance>& ambulances) {
    std::vector<Route> routes;
    std::vector<bool> assignedCalls(calls.size(), false);
    
    // Sort calls by priority
    std::vector<int> callIndices(calls.size());
    for (size_t i = 0; i < calls.size(); i++) {
        callIndices[i] = i;
    }
    std::sort(callIndices.begin(), callIndices.end(),
             [&calls](int a, int b) {
                 return calls[a].getPriority() > calls[b].getPriority();
             });
    
    // Assign each call to nearest available ambulance
    for (int idx : callIndices) {
        auto& call = calls[idx];
        Ambulance* assigned = assignOptimalAmbulance(call, ambulances);
        
        if (assigned) {
            Route route;
            route.addWaypoint(assigned->getCurrentLocation());
            route.addWaypoint(call.getLocation());
            routes.push_back(route);
            assigned->setStatus(AmbulanceStatus::EN_ROUTE);
            assignedCalls[idx] = true;
        }
    }
    
    return routes;
}

std::vector<Route> RouteOptimizer::solveVRPGreedy(std::vector<EmergencyCall>& calls,
                                                  std::vector<Ambulance>& ambulances) {
    // Similar to Nearest Neighbor but with different selection criteria
    return solveVRPNearestNeighbor(calls, ambulances);
}

void RouteOptimizer::clearCache() {
    routeCache.clear();
}

void RouteOptimizer::print() const {
    std::cout << "RouteOptimizer Status:" << std::endl;
    std::cout << "  Cached routes: " << routeCache.size() << std::endl;
}
