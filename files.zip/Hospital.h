#ifndef HOSPITAL_H
#define HOSPITAL_H

#include "Location.h"
#include <vector>
#include <string>

class Ambulance; // Forward declaration

/**
 * @class Hospital
 * @brief Represents a hospital with location and ambulance capacity
 * 
 * Hospital extends Location to represent a geographic location
 * and manages a fleet of ambulances based on capacity constraints.
 */
class Hospital : public Location {
private:
    std::string name;               ///< Hospital name
    int totalCapacity;              ///< Maximum number of ambulances
    std::vector<Ambulance*> ambulances;  ///< Parking ambulances

public:
    /**
     * @brief Constructor for Hospital
     * @param lat Latitude of hospital
     * @param lon Longitude of hospital
     * @param name Hospital name
     * @param capacity Maximum ambulance capacity
     */
    Hospital(double lat, double lon, const std::string& name, int capacity);
    
    // Getters
    /**
     * @return Hospital name
     */
    std::string getName() const { return name; }
    
    /**
     * @return Total capacity
     */
    int getTotalCapacity() const { return totalCapacity; }
    
    /**
     * @return Number of available slots
     */
    int getAvailableCapacity() const;
    
    /**
     * @return Current number of ambulances at hospital
     */
    int getCurrentAmbulances() const { return ambulances.size(); }
    
    // Methods
    /**
     * @brief Add an ambulance to the hospital
     * @param ambulance Pointer to ambulance to add
     */
    void addAmbulance(Ambulance* ambulance);
    
    /**
     * @brief Remove an ambulance from the hospital
     * @param ambulance Pointer to ambulance to remove
     */
    void removeAmbulance(Ambulance* ambulance);
    
    /**
     * @brief Check if hospital is at full capacity
     * @return true if no available slots
     */
    bool isFull() const;
    
    /**
     * @brief Check if hospital has no ambulances
     * @return true if empty
     */
    bool isEmpty() const;
    
    /**
     * @brief Print hospital information
     */
    void print() const;
};

#endif // HOSPITAL_H
