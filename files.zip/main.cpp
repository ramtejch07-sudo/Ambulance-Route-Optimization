#include <iostream>
#include <vector>
#include "Location.h"
#include "Hospital.h"
#include "Ambulance.h"
#include "EmergencyCall.h"
#include "Route.h"
#include "Graph.h"
#include "RouteOptimizer.h"
#include "Manager.h"

void printHeader() {
    std::cout << "\n";
    std::cout << "╔══════════════════════════════════════════════════════════╗" << std::endl;
    std::cout << "║   Ambulance Route Optimization System - Week 1-2         ║" << std::endl;
    std::cout << "║   OOP C++ Project                                        ║" << std::endl;
    std::cout << "╚══════════════════════════════════════════════════════════╝" << std::endl;
    std::cout << std::endl;
}

void testLocationClass() {
    std::cout << "=== Testing Location Class ===" << std::endl;
    
    Location loc1(40.7128, -74.0060);  // Times Square, NYC
    Location loc2(40.7150, -74.0070);  // Near Times Square
    
    std::cout << "Location 1: ";
    loc1.print();
    
    std::cout << "Location 2: ";
    loc2.print();
    
    double distance = loc1.getDistance(loc2);
    std::cout << "Distance between locations: " << distance << " meters" << std::endl;
    
    bool equal = (loc1 == loc2);
    std::cout << "Are they equal? " << (equal ? "Yes" : "No") << std::endl << std::endl;
}

void testAmbulanceClass() {
    std::cout << "=== Testing Ambulance Class ===" << std::endl;
    
    Location hospitalLoc(40.7128, -74.0060);
    Ambulance amb1(1, hospitalLoc, 2);
    Ambulance amb2(2, hospitalLoc, 2);
    
    std::cout << "Created two ambulances:" << std::endl;
    amb1.print();
    std::cout << std::endl;
    amb2.print();
    std::cout << std::endl;
    
    // Change status
    amb1.setStatus(AmbulanceStatus::EN_ROUTE);
    std::cout << "After status change:" << std::endl;
    amb1.print();
    std::cout << std::endl;
}

void testHospitalClass() {
    std::cout << "=== Testing Hospital Class ===" << std::endl;
    
    Hospital hospital(40.7128, -74.0060, "General Hospital", 5);
    
    std::cout << "Hospital details:" << std::endl;
    hospital.print();
    std::cout << std::endl;
}

void testEmergencyCallClass() {
    std::cout << "=== Testing EmergencyCall Class ===" << std::endl;
    
    Location callLoc(40.7150, -74.0070);
    EmergencyCall call1(1, callLoc, 4, "Chest pain, 65-year-old male");
    EmergencyCall call2(2, callLoc, 2, "Minor injury");
    
    std::cout << "Emergency Call 1 (High Priority):" << std::endl;
    call1.print();
    std::cout << std::endl;
    
    std::cout << "Emergency Call 2 (Low Priority):" << std::endl;
    call2.print();
    std::cout << std::endl;
}

void testRouteClass() {
    std::cout << "=== Testing Route Class ===" << std::endl;
    
    Location start(40.7128, -74.0060);
    Location waypoint1(40.7150, -74.0070);
    Location waypoint2(40.7180, -74.0080);
    Location end(40.7200, -74.0090);
    
    Route route(start);
    route.addWaypoint(waypoint1);
    route.addWaypoint(waypoint2);
    route.addWaypoint(end);
    
    std::cout << "Route created with 4 waypoints:" << std::endl;
    route.print();
    std::cout << std::endl;
    
    std::cout << "Detailed route:" << std::endl;
    route.printDetailed();
    std::cout << std::endl;
}

void testGraphClass() {
    std::cout << "=== Testing Graph Class ===" << std::endl;
    
    Graph roadNetwork(5);
    
    // Add nodes representing intersections
    roadNetwork.addNode(0, "Hospital");
    roadNetwork.addNode(1, "Intersection A");
    roadNetwork.addNode(2, "Intersection B");
    roadNetwork.addNode(3, "Intersection C");
    roadNetwork.addNode(4, "Emergency Location");
    
    // Add edges representing roads with distances
    roadNetwork.addEdge(0, 1, 1000);   // 1 km
    roadNetwork.addEdge(1, 2, 1500);   // 1.5 km
    roadNetwork.addEdge(2, 3, 2000);   // 2 km
    roadNetwork.addEdge(3, 4, 1200);   // 1.2 km
    roadNetwork.addEdge(1, 3, 2500);   // Alternate route
    
    std::cout << "Road network created:" << std::endl;
    roadNetwork.print();
    std::cout << std::endl;
    
    roadNetwork.printStatistics();
    std::cout << std::endl;
}

void testManagerSystem() {
    std::cout << "=== Testing Full Management System ===" << std::endl;
    
    // Create road network
    Graph roadNetwork(10);
    for (int i = 0; i < 9; i++) {
        roadNetwork.addEdge(i, i+1, 1000 + i*100);
    }
    
    // Create manager
    Manager manager(&roadNetwork);
    
    // Add hospitals
    Hospital hospital1(40.7128, -74.0060, "General Hospital", 5);
    Hospital hospital2(40.7200, -74.0100, "Metro Hospital", 3);
    
    manager.addHospital(hospital1);
    manager.addHospital(hospital2);
    
    // Add ambulances
    Location ambulanceStart(40.7128, -74.0060);
    for (int i = 1; i <= 4; i++) {
        Ambulance amb(i, ambulanceStart, 2);
        manager.addAmbulance(amb);
    }
    
    std::cout << "System initialized:" << std::endl;
    manager.print();
    std::cout << std::endl;
    
    // Create emergency calls
    std::cout << "Processing emergency calls..." << std::endl;
    Location call1Loc(40.7140, -74.0065);
    Location call2Loc(40.7160, -74.0075);
    Location call3Loc(40.7180, -74.0085);
    
    EmergencyCall call1(1, call1Loc, 5, "Critical - Cardiac arrest");
    EmergencyCall call2(2, call2Loc, 3, "Moderate - Accident");
    EmergencyCall call3(3, call3Loc, 2, "Minor - Injury");
    
    manager.processEmergencyCall(call1);
    manager.processEmergencyCall(call2);
    manager.processEmergencyCall(call3);
    
    std::cout << "\nSystem status after call processing:" << std::endl;
    manager.print();
    std::cout << std::endl;
    
    std::cout << "Detailed report:" << std::endl;
    manager.printDetailedReport();
    std::cout << std::endl;
    
    std::cout << "Statistics:" << std::endl;
    manager.printStatistics();
    std::cout << std::endl;
}

int main() {
    try {
        printHeader();
        
        std::cout << "Running Week 1-2 Basic Tests..." << std::endl;
        std::cout << "================================" << std::endl;
        
        // Run individual class tests
        testLocationClass();
        testAmbulanceClass();
        testHospitalClass();
        testEmergencyCallClass();
        testRouteClass();
        testGraphClass();
        testManagerSystem();
        
        std::cout << "╔══════════════════════════════════════════════════════════╗" << std::endl;
        std::cout << "║                  All Tests Completed!                    ║" << std::endl;
        std::cout << "║                                                          ║" << std::endl;
        std::cout << "║  Next Steps:                                             ║" << std::endl;
        std::cout << "║  - Week 3: Implement core algorithms                    ║" << std::endl;
        std::cout << "║  - Week 4: Add data validation                          ║" << std::endl;
        std::cout << "║  - Week 5-6: Implement pathfinding                      ║" << std::endl;
        std::cout << "╚══════════════════════════════════════════════════════════╝" << std::endl;
        
        return 0;
        
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
}
