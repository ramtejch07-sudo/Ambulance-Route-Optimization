#ifndef ROUTE_H
#define ROUTE_H

#include "Location.h"
#include <vector>
#include <cmath>
#include <iostream>

/**
 * @class Route
 * @brief Represents a route consisting of waypoints
 * 
 * A route is a sequence of locations that an ambulance must visit.
 * It automatically calculates total distance and estimated travel time.
 */
class Route {
private:
    std::vector<Location> waypoints;    ///< Sequence of locations
    double totalDistance;               ///< Total distance in meters
    double estimatedTime;               ///< Estimated time in seconds

public:
    /**
     * @brief Default constructor
     * 
     * Creates an empty route with 0 distance and time
     */
    Route();
    
    /**
     * @brief Constructor with starting location
     * @param start Starting location
     */
    explicit Route(Location start);
    
    // Methods
    /**
     * @brief Add a waypoint to the route
     * @param loc Location to add
     */
    void addWaypoint(Location loc);
    
    /**
     * @brief Add multiple waypoints at once
     * @param locations Vector of locations
     */
    void addWaypoints(const std::vector<Location>& locations);
    
    /**
     * @brief Remove all waypoints
     */
    void clearWaypoints();
    
    /**
     * @brief Recalculate total distance
     */
    void calculateDistance();
    
    /**
     * @brief Recalculate estimated time
     * 
     * Assumes average speed of 40 km/h (11.11 m/s)
     */
    void calculateTime();
    
    // Getters
    /**
     * @return All waypoints
     */
    std::vector<Location> getWaypoints() const { return waypoints; }
    
    /**
     * @return Total distance in meters
     */
    double getTotalDistance() const { return totalDistance; }
    
    /**
     * @return Estimated time in seconds
     */
    double getEstimatedTime() const { return estimatedTime; }
    
    /**
     * @return Estimated time in minutes
     */
    double getEstimatedTimeMinutes() const { return estimatedTime / 60.0; }
    
    /**
     * @return Number of waypoints
     */
    size_t getWaypointCount() const { return waypoints.size(); }
    
    // Status checks
    /**
     * @brief Check if route has no waypoints
     * @return true if empty
     */
    bool isEmpty() const { return waypoints.empty(); }
    
    /**
     * @brief Check if route is valid (has at least 2 points)
     * @return true if valid
     */
    bool isValid() const { return waypoints.size() >= 2; }
    
    // Operators
    /**
     * @brief Compare routes by distance
     * @param other Route to compare
     * @return true if this route is shorter
     */
    bool operator<(const Route& other) const {
        return totalDistance < other.totalDistance;
    }
    
    /**
     * @brief Compare routes by distance (greater than)
     * @param other Route to compare
     * @return true if this route is longer
     */
    bool operator>(const Route& other) const {
        return totalDistance > other.totalDistance;
    }
    
    /**
     * @brief Compare routes for equality
     * @param other Route to compare
     * @return true if same waypoints
     */
    bool operator==(const Route& other) const;
    
    // Utility methods
    /**
     * @brief Print route information
     */
    void print() const;
    
    /**
     * @brief Print detailed route information
     */
    void printDetailed() const;
    
    /**
     * @brief Get starting location
     * @return Starting point (or invalid if empty)
     */
    Location getStart() const;
    
    /**
     * @brief Get ending location
     * @return End point (or invalid if empty)
     */
    Location getEnd() const;
};

#endif // ROUTE_H
