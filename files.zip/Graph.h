#ifndef GRAPH_H
#define GRAPH_H

#include <vector>
#include <map>
#include <queue>
#include <limits>
#include <iostream>
#include <string>

/**
 * @class Graph
 * @brief Represents a road network as a graph
 * 
 * Uses adjacency list representation to store nodes (intersections/locations)
 * and weighted edges (roads with distances). Supports pathfinding algorithms.
 */
class Graph {
private:
    int numNodes;                                       ///< Total number of nodes
    std::map<int, std::vector<std::pair<int, double>>> adjacencyList;  ///< Node -> (neighbor, weight)
    std::map<int, std::string> nodeLabels;              ///< Node ID to name mapping

public:
    /**
     * @brief Constructor for Graph
     * @param nodes Maximum number of nodes
     */
    explicit Graph(int nodes);
    
    // Methods for building graph
    /**
     * @brief Add a node to the graph
     * @param nodeId Unique node identifier
     * @param label Optional node label/name
     */
    void addNode(int nodeId, const std::string& label = "");
    
    /**
     * @brief Add an edge between two nodes
     * @param from Source node ID
     * @param to Destination node ID
     * @param weight Edge weight (distance/cost)
     * @param bidirectional If true, adds reverse edge as well
     */
    void addEdge(int from, int to, double weight, bool bidirectional = true);
    
    /**
     * @brief Remove an edge
     * @param from Source node ID
     * @param to Destination node ID
     */
    void removeEdge(int from, int to);
    
    // Getters
    /**
     * @return Total number of nodes
     */
    int getNumNodes() const { return numNodes; }
    
    /**
     * @brief Get all neighbors of a node
     * @param nodeId Node ID
     * @return Vector of (neighbor ID, weight) pairs
     */
    std::vector<std::pair<int, double>> getNeighbors(int nodeId) const;
    
    /**
     * @brief Get edge weight between two nodes
     * @param from Source node
     * @param to Destination node
     * @return Weight if edge exists, -1 otherwise
     */
    double getEdgeWeight(int from, int to) const;
    
    /**
     * @brief Get node label
     * @param nodeId Node ID
     * @return Node name/label
     */
    std::string getNodeLabel(int nodeId) const;
    
    // Graph queries
    /**
     * @brief Check if two nodes are directly connected
     * @param from Source node
     * @param to Destination node
     * @return true if edge exists
     */
    bool isConnected(int from, int to) const;
    
    /**
     * @brief Check if node exists in graph
     * @param nodeId Node ID
     * @return true if node exists
     */
    bool nodeExists(int nodeId) const;
    
    /**
     * @brief Get all nodes reachable from a source
     * @param source Source node ID
     * @return Vector of reachable node IDs
     */
    std::vector<int> getReachableNodes(int source) const;
    
    // Pathfinding - Dijkstra's Algorithm
    /**
     * @brief Find shortest path using Dijkstra's algorithm
     * @param start Starting node ID
     * @param end Ending node ID
     * @return Vector of node IDs representing path (empty if no path)
     */
    std::vector<int> dijkstra(int start, int end);
    
    /**
     * @brief Dijkstra with distance tracking
     * @param start Starting node
     * @param distances Output: vector of distances from start
     * @return Predecessors map for path reconstruction
     */
    std::map<int, int> dijkstraDistances(int start, 
                                         std::vector<double>& distances);
    
    // Utility methods
    /**
     * @brief Print all edges in the graph
     */
    void print() const;
    
    /**
     * @brief Print adjacency list representation
     */
    void printAdjacencyList() const;
    
    /**
     * @brief Get graph statistics
     */
    void printStatistics() const;
    
    /**
     * @brief Check if graph is connected
     * @return true if all nodes are reachable from node 0
     */
    bool isConnected() const;
    
    /**
     * @brief Clear all edges and nodes
     */
    void clear();
    
    /**
     * @brief Get number of edges in graph
     * @return Total edge count
     */
    int getEdgeCount() const;

private:
    /**
     * @brief DFS helper for connectivity check
     * @param node Current node
     * @param visited Set of visited nodes
     */
    void dfs(int node, std::vector<bool>& visited) const;
};

#endif // GRAPH_H
